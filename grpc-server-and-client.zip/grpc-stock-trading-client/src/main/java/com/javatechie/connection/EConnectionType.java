package com.javatechie.connection;

public enum EConnectionType {
    ETHERNET,
    GRPC
}
