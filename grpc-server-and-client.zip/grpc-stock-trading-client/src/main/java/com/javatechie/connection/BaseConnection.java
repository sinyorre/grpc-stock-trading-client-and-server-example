package com.javatechie.connection;

public interface BaseConnection {
    void run();
    EConnectionType getConnectionType();
}
