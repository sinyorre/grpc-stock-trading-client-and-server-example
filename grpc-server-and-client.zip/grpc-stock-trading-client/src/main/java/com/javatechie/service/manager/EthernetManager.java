package com.javatechie.service.manager;

public class EthernetManager implements BaseManager{
}
