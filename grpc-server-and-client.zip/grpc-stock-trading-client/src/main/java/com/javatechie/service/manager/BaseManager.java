package com.javatechie.service.manager;

public interface BaseManager {
}
