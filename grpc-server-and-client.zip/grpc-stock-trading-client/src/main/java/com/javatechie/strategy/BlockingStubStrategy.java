package com.javatechie.strategy;

import com.javatechie.grpc.StockRequest;
import com.javatechie.grpc.StockResponse;
import com.javatechie.grpc.StockTradingServiceGrpc;

public class BlockingStubStrategy implements StockStubStrategy {
    private final StockTradingServiceGrpc.StockTradingServiceBlockingStub blockingStub;

    public BlockingStubStrategy(StockTradingServiceGrpc.StockTradingServiceBlockingStub blockingStub) {
        this.blockingStub = blockingStub;
    }

    @Override
    public void get(StockRequest stockRequest) {
        StockResponse stockStatus = blockingStub.getStockStatus(stockRequest);
        System.out.println("status received for : " + stockStatus.getStockSymbol());
        // send to ui via ws
    }
}
